This is my solutions to tutorial 1. Nothing much to talk about here since all we have to do is following the instructions in the tut document.
